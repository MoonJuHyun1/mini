package com.teco.train.service;

import java.util.ArrayList;
import com.teco.train.domain.Traininfo;

public interface TraininfoService {

	public ArrayList<Traininfo> selectalltrains();
	public int sele();
}
